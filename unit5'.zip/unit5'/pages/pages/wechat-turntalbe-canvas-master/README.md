# 微信小程序转盘抽奖
----

## 简介

用微信小程序开发的Canvas绘制可配置的转盘抽奖。      

使用[https://github.com/givebest/GB-canvas-turntable](http://blog.givebest.cn/GB-canvas-turntable.html)代码移植过而来。

      
## 其它

微信小程序感觉是个半成品，代码移植过程比较繁琐麻烦。`canvas` API 部分都被重写了。。。      
`canvas` `z-index`不生效，永远在最上层，不支持`rotate`动画。


## License

[MIT](./LICENSE) © 2016 [givebest](https://github.com/givebest)

 
